from django.db import models
import uuid

class ApplicationCode(models.Model):
    app_code = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.app_code

class JoinConditions(models.Model):
    uploaded_file = models.CharField(max_length=255)
    jc_s_no = models.CharField(max_length=50) 
    mapping_ref_name = models.CharField(max_length=255)  # Mapping Ref Name
    table_1 = models.CharField(max_length=100) # Table 1
    table_2 = models.CharField(max_length=100) # Table 2
    join = models.TextField(blank=True, null=True) # Join condition

    def __str__(self):
        return f"{self.uploaded_file} | {self.table_1} -> {self.table_2}"

class Mappings(models.Model):
    uploaded_file = models.CharField(max_length=255)
    s_no = models.CharField(max_length=50)
    target_app_code = models.CharField(max_length=50)
    target_table_name = models.CharField(max_length=100)
    target_column_name_physical = models.CharField(max_length=100)
    source_app_code = models.CharField(max_length=50)
    source_table_name = models.CharField(max_length=100)
    country_applicability = models.CharField(max_length=100)
    source_column_name_physical = models.CharField(max_length=100)
       
    def __str__(self):
        return f"{self.uploaded_file} | {self.source_column_name} -> {self.target_column_name_physical}"
       
class MappingAudit(models.Model):
    app_code = models.CharField(max_length=100)  # Store the app code here
    uploaded_file = models.CharField(max_length=255)  # Store the file name here
    action = models.CharField(max_length=50)
    performed_by = models.CharField(max_length=100)
    performed_at = models.DateTimeField(auto_now_add=True)
    remarks = models.TextField(blank=True)

    def __str__(self):
        return f"File: {self.uploaded_file} | Action: {self.action} by {self.performed_by}"