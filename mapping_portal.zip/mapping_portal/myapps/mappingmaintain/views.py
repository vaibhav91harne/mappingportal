import os
import pandas as pd
from django.shortcuts import render, redirect
from django.conf import settings
from django.contrib import messages
from django.utils.timezone import now
from myapps.mappingmaintain.models import JoinConditions, Mappings, MappingAudit, ApplicationCode
import re, math

def mapping_list(request):
    """View to display all mappings organized by system"""
    return render(request, 'myapps/mappingmaintain/templates/mapping_list.html')

def export_mapping(request):
    """View to display all mappings organized by system"""
    return render(request, 'myapps/mappingmaintain/templates/exportmapping.html')

def is_valid_field(value):
    pattern = r'^[a-zA-Z0-9_.]+$'
    return bool(re.match(pattern, value))

def generate_log_file(errors, filename_prefix):
    log_dir = os.path.join(settings.MEDIA_ROOT, 'upload_logs')
    os.makedirs(log_dir, exist_ok=True)
    log_filename = f"{filename_prefix}_{now().strftime('%Y%m%d%H%M%S')}.csv"
    log_path = os.path.join(log_dir, log_filename)

    # Convert the errors list to DataFrame and save it as CSV
    error_df = pd.DataFrame(errors)
    error_df.to_csv(log_path, index=False)

    return f"upload_logs/{log_filename}"  # Relative path for the database

def upload_mapping(request):
    user_id = request.session.get('user_id', 'unknown')

    if request.method == 'POST':
        app_code_input = request.POST.get('app_code')
        uploaded_file = request.FILES.get('file')

        if not app_code_input or not uploaded_file:
            messages.error(request, "App code and file are required.")
            return redirect('mappingmaintain:upload_mapping')

        try:
            # Read the first sheet of the uploaded file into a DataFrame without headers initially
            df_all = pd.read_excel(uploaded_file, sheet_name=0, header=None)  # Read as raw data
        except Exception as e:
            messages.error(request, f"Error reading file: {str(e)}")
            return redirect('mappingmaintain:upload_mapping')

        # Create the MappingAudit entry even before validation starts
        audit_entry = MappingAudit.objects.create(
            app_code=app_code_input,
            uploaded_file=uploaded_file.name,  # Store the file name in the audit log
            action='upload started',
            performed_by=user_id,
            remarks=f'Starting upload for file {uploaded_file.name}',
        )

        # Define expected headers for JoinConditions and Mappings
        join_headers = ["jc_s_no", "mapping_ref_name", "table_1", "table_2", "join"]
        map_headers = ["s_no", "target_app_code", "target_table_name", "target_column_name_physical", 
                       "source_app_code", "source_table_name", "country_applicability", "source_column_name_physical"]

        # Initialize the starting indices for JoinConditions and Mappings
        join_start_idx = None
        map_start_idx = None

        # Scan the entire DataFrame to find the starting point of each table (scan all cells)
        for i, row in df_all.iterrows():
            for col_name, cell_value in row.items():
                # Look for 'jc_s_no' in any cell (start of JoinConditions table)
                if pd.notna(cell_value) and str(cell_value).strip().lower() == "jc_s_no" and join_start_idx is None:
                    join_start_idx = i
                # Look for 's_no' in any cell (start of Mappings table)
                if pd.notna(cell_value) and str(cell_value).strip().lower() == "s_no" and map_start_idx is None:
                    map_start_idx = i

        # Check if the required columns for JoinConditions or Mappings are not found
        if join_start_idx is None or map_start_idx is None:
            messages.error(request, "❌ Could not find the required starting columns in the file.")
            audit_entry.action = 'upload failed'
            audit_entry.remarks = "Failed to find required columns"
            audit_entry.save()  # Save the updated audit entry
            return redirect('mappingmaintain:upload_mapping')

        # Read the sections of the DataFrame for JoinConditions and Mappings based on the indices
        join_df = pd.read_excel(uploaded_file, sheet_name=0, header=join_start_idx)
        map_df = pd.read_excel(uploaded_file, sheet_name=0, header=map_start_idx)

        # Clean up the columns by renaming or removing unnamed columns (same as before)
        join_df.columns = join_df.columns.str.strip()  # Remove leading/trailing spaces in column names
        map_df.columns = map_df.columns.str.strip()  # Remove leading/trailing spaces in column names

        # Remove any unnamed or empty columns
        join_df = join_df.loc[:, ~join_df.columns.str.contains('^Unnamed|^$', na=False)]
        map_df = map_df.loc[:, ~map_df.columns.str.contains('^Unnamed|^$', na=False)]

        # Filter JoinConditions to keep only rows where 'jc_s_no' starts with 'JC' or 'jc'
        join_df = join_df[join_df['jc_s_no'].str.match(r'^jc.*', case=False, na=False)]

        # Ensure the columns match the expected headers
        if not all(col in join_df.columns for col in join_headers):
            messages.error(request, f"❌ Missing required columns for JoinConditions. Expected: {join_headers}")
            audit_entry.action = 'upload failed'
            audit_entry.remarks = "Missing required columns for JoinConditions"
            audit_entry.save()  # Save the updated audit entry
            return redirect('mappingmaintain:upload_mapping')

        if not all(col in map_df.columns for col in map_headers):
            messages.error(request, f"❌ Missing required columns for Mappings. Expected: {map_headers}")
            audit_entry.action = 'upload failed'
            audit_entry.remarks = "Missing required columns for Mappings"
            audit_entry.save()  # Save the updated audit entry
            return redirect('mappingmaintain:upload_mapping')

        # Initialize error list
        errors = []

        # Validate JoinConditions using the is_valid_field function
        for idx, row in join_df.iterrows():
            for col in join_headers:
                value = row[col]
                if pd.isna(value) or value == "":
                    errors.append({
                        'row': idx + 2,  # Row number (1-based index)
                        'column': col,
                        'value': value,
                        'error': f"Missing value in {col}"
                    })
                # Check for invalid characters in specific columns (e.g., table_1, table_2)
                if col in ['table_1', 'table_2'] and not is_valid_field(value):
                    errors.append({
                        'row': idx + 2,
                        'column': col,
                        'value': value,
                        'error': f"Invalid character in {col}"
                    })

        # Validate Mappings using the is_valid_field function
        for idx, row in map_df.iterrows():
            for col in map_headers:
                value = row[col]
                if pd.isna(value) or value == "":
                    errors.append({
                        'row': idx + 2,  # Row number (1-based index)
                        'column': col,
                        'value': value,
                        'error': f"Missing value in {col}"
                    })
                # Check for invalid characters in specific columns (e.g., target_app_code, source_column_name_physical)
                if col in ['target_app_code', 'target_table_name', 'target_column_name_physical', 
                           'source_app_code', 'source_table_name', 'source_column_name_physical'] and not is_valid_field(value):
                    errors.append({
                        'row': idx + 2,
                        'column': col,
                        'value': value,
                        'error': f"Invalid character in {col}"
                    })

        # If there are errors, generate the log file and save it
        if errors:
            log_file_path = generate_log_file(errors, "upload_error")
            MappingAudit.objects.create(
                app_code=app_code_input,
                uploaded_file=uploaded_file.name,
                action='upload failed',
                performed_by=user_id,
                remarks=log_file_path  # Log file path here
            )
            audit_entry.action = 'upload failed'
            audit_entry.remarks = "Validation failed. See log file."
            audit_entry.save()  # Save the updated audit entry
            messages.error(request, "❌ Validation failed. See log below.")
            return redirect('mappingmaintain:upload_mapping')

        # If no errors, save the data into the database (JoinConditions and Mappings)
        for _, row in join_df.iterrows():
            JoinConditions.objects.create(
                jc_s_no=row['jc_s_no'],
                mapping_ref_name=row['mapping_ref_name'],
                table_1=row['table_1'],
                table_2=row['table_2'],
                join=row.get('join', ''),
                uploaded_file=uploaded_file.name  # Save file name
            )

        for _, row in map_df.iterrows():
            Mappings.objects.create(
                s_no=row['s_no'],
                target_app_code=row['target_app_code'],
                target_table_name=row['target_table_name'],
                target_column_name_physical=row['target_column_name_physical'],
                source_app_code=row['source_app_code'],
                source_table_name=row['source_table_name'],
                country_applicability=row['country_applicability'],
                source_column_name_physical=row['source_column_name_physical'],
                uploaded_file=uploaded_file.name  # Save file name
            )

        # Log the successful upload
        audit_entry.action = 'upload successful'
        audit_entry.remarks = f'Mapping uploaded for file {uploaded_file.name}'
        audit_entry.save()  # Save the updated audit entry

        messages.success(request, f"✅ File '{uploaded_file.name}' uploaded successfully.")
        return redirect('mappingmaintain:upload_mapping')

    # GET request: show recent uploads
    recent_uploads = MappingAudit.objects.filter(performed_by=user_id).order_by('-performed_at')[:20]
    for entry in recent_uploads:
        entry.is_log_file = entry.remarks and str(entry.remarks).endswith('.csv')

    return render(request, 'myapps/mappingmaintain/templates/uploadmapping.html', {
        'recent_uploads': recent_uploads,
        'MEDIA_URL': settings.MEDIA_URL
    })
