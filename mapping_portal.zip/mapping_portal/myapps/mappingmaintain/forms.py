from django import forms

class MappingUploadForm(forms.Form):
    app_code = forms.CharField(label="Application Code", max_length=50)
    file = forms.FileField(label="Upload CSV or XLSX")