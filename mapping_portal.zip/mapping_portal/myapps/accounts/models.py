from django.db import models

class UserData(models.Model):
    user_id = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=100)
    permissions = models.CharField(max_length=50)

    def __str__(self):
        return self.user_id