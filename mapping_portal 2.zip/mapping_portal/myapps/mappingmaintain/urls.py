from django.urls import path
from . import views
from myapps.mappingmaintain import views
from .views import upload_mapping

app_name = 'mappingmaintain'

urlpatterns = [
    path('', views.mapping_list, name='mapping_list'),
  # path('edit/<int:mapping_id>/', views.edit_mapping, name='edit_mapping'),
#  path('create/', views.create_mapping, name='create_mapping'),
    #path('delete/<int:mapping_id>/', views.delete_mapping, name='delete_mapping'),
    path('exportmapping/', views.export_mapping, name='export_mapping'),
    path('uploadmapping/', upload_mapping, name='upload_mapping'),
]