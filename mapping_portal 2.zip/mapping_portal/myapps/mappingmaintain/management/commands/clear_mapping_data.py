from django.core.management.base import BaseCommand
from myapps.mappingmaintain.models import ApplicationCode, Mappings, JoinConditions, MappingAudit

class Command(BaseCommand):
    help = 'Delete all data from ApplicationCode, Mappings, JoinConditions, and MappingAudit tables.'

    def handle(self, *args, **kwargs):
        self.stdout.write("⚠️  Clearing all mapping-related data...")

        ApplicationCode.objects.all().delete()
        Mappings.objects.all().delete()
        JoinConditions.objects.all().delete()
        MappingAudit.objects.all().delete()

        self.stdout.write(self.style.SUCCESS("✅ Successfully cleared all data from mappingmaintain models."))
