from django.urls import path
from myapps.mappings import views
from .views import custom_login

app_name = 'mappings'

urlpatterns = [
    #path('', views.login, name='login.html'),
    path('news/', views.news, name='news.html'),
    path('contact/', views.contact, name='contact.html'),
    path('about/', views.about, name='about.html'),
    path('', custom_login, name='custom_login'),
    path('home/', views.home, name='home'),
    path('edit/<str:file_name>/', views.edit_mapping_file, name='edit_mapping_file'),
]
