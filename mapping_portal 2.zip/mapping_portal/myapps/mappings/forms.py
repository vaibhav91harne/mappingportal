from django import forms

class CustomLoginForm(forms.Form):
    lan_id = forms.CharField(label="LAN ID", max_length=50)
    password = forms.CharField(widget=forms.PasswordInput)