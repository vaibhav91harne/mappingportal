from django.apps import AppConfig


class AdminconsoleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myapps.adminconsole'
